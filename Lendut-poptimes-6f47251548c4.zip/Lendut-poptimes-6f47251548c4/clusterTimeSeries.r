library("dtwclust")
library("TSclust")

#read all venues distributions for country,city
place <- "us/chicago"
m <- read.table(paste("signatures/weekdays_clust/", place, ".txt", sep=""),sep=',');

#normalize
newM <- c()
for (h in 1:nrow(m)){
  if(max(m[h,]) != 0){
    normalizado1 <- m[h,]/max(m[h,])
    newM <- rbind(newM,normalizado1)  
  }else{
    newM <- rbind(newM,m[h,])  
  }
}

#Usando DTW como diferenciacao de curvas
tsdist <- diss( data.matrix(newM), "DTWARP")

#perform hierachical clustering to the dist object
hc <- hclust(tsdist)

#plot and save results
setEPS()
  postscript(paste("signatures/hierarchical/", place, "/dendrograma.eps",sep = ""))
  par(cex.lab=2, cex.axis=1.5, mar= c(5, 5, 4, 2) + 0.1)
  plot(hc,ylab="Height",main="", sub="",labels=FALSE, hang = -1,xlab="",  cex.lab=1.5, cex.axis=1.5)
  altura<-6.6
  abline(h = altura, lty = 2,col="red")
dev.off()

#clusters metodo dtw
clusterCut <- cutree(hc,h=altura)
numberCluster<-9

#Usa todas as categorias 
nomesOriginais <- scan(paste("signatures/weekdays_clust/",place,"_categories_names.txt",sep=""), what = character(),sep='\n',quote="\"")

#Separa as timeseries dos clusters 
for (clust in 1:numberCluster){
  count<-1

  #contem os nomes das subcategorias em cada cluster
  saida<-c()
  
  #contem as time series de cada cluster
  series<-c()
  
  for(i in clusterCut){
    saida[i[1]]<-paste(saida[i[1]], nomesOriginais[count], sep=",")
    if(i == clust){
      series<-rbind(series,newM[count,])
    }
    count <- count+1
  }
  
  transpose = t(series)
  timeseries <- ts(transpose,start = 0,end = 23)
  
  # find centroid
  cent <- colMeans(series)
  #clusters = cutree(hclust(tsdist), k=1) # get 1 cluster
  #clust.centroid = function(i, dat, clusters) {
    #ind = (clusters == i)
    #colMeans(dat[ind,])
  #}
  #cent <- sapply(unique(clusters), clust.centroid, series, clusters)
  
  
  # iterated processing DBA 
  dtw_avg <- matrix(,nrow=50,ncol=24)
  for(i in 1:50){
    dtw_avg[i,] <- DBA(t(timeseries), trace = F)
  }
  
  #calculate DBA
  signature <- DBA(dtw_avg,centroid = cent,trace = TRUE)
  
  #para salvar em eps
  setEPS()
    postscript(paste("signatures/hierarchical/",place,"/",numberCluster,"/timeSeriesCluster_",clust,".eps",sep = ""))
    
    #color
    #'mar' define as marges da figura
    #'par' define as configuracoes atuais dos plots 
    par(cex.lab=2, cex.axis=1.5, mar= c(5, 5, 4, 2) + 0.1)
    #ts.plot(transpose,gpars= list(xaxt="n",col=rainbow(10)),ylab="Popularity",xlab="Time (hours)")
    seriesNum <- ncol(timeseries)
    ts.plot(timeseries,xlab="Hora",ylab="Popularidade",gpars=list(xaxt="n",col=rep(rainbow(10),seriesNum)),main="")
    par(new=TRUE)
    ts.plot(signature,xlab="Hora",ylab="Popularidade",gpars=list(xaxt="n",yaxt="n",lwd=5),main="")
    axis(1, at=1:24, labels = seq(from=0, to=23, by = 1), las=2)
  dev.off()
}    

write.table(saida, paste("signatures/hierarchical/",place,"/timeSeriesClusterCategories_",clust,".txt",sep = ""), sep="\n",col.names = F, row.names = F)
