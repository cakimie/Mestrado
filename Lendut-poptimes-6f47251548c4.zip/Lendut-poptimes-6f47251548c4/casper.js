// ~/node_modules/casperjs/bin/casperjs casper.js
// Inicia Casper, simulando User Agent
var casper = require('casper').create({
    pageSettings: {
        userAgent: 'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36'
    }
});

// Vai até o endereço
casper.start('http://google.com/');

casper.then(function() {
	var country = 'us';
	var cities = ['curitiba', 'sao paulo', 'rio de janeiro'];
	// var cities = ['chicago', 'new york', 'san francisco'];
	var categories = ['bakeries', 'bars', 'coffee', 'dance clubs', 'restaurants', 'shopping centers'];
    var fs = require('fs');


    for(k in cities){
    	var file_path = country + '/' + cities[k] + '/';
	    for(j in categories) {
			var data = fs.read(fs.workingDirectory +'/business_names/' + file_path + categories[j] + '.txt');
			var array = data.toString().split("\n");
			var url = '';
			var qtd = new qtd_holder();

			// this.echo(data.toString());
		    for(i in array) {;
		    	url = 'https://www.google.com.br/search?q=' + array[i] + '+' + cities[k] + '+' + categories[j];
		    	getPage(url, fs.workingDirectory +'/poptimes_raw/' + file_path + categories[j] +'/', i, qtd, array[i]);
		    }
		}
	}
});

function qtd_holder(){
	this.value = 0;
}

qtd_holder.prototype.add = function(){
	this.value++;
}


function getPage(url, file_path, i, qtd, name){
	var fs = require('fs');

	casper.wait(3000, function(){
		casper.thenOpen(url, function() {
			this.page.injectJs('jquery-latest.js');
			console.log(i);

				casper.waitFor(function check() {
				    return this.evaluate(function() {
				        return document.querySelector('div._ppj').querySelectorAll('div._kpj').length > 6;
				    });
				}, function then() {
					// console.log(document.querySelector('div._ppj').querySelectorAll('div').length);
					qtd.add();
				    console.log('a:' + qtd.value);
		        	fs.write(file_path + qtd.value + '.html', name + '\n' + this.getHTML('div._ppj'), 'w');
				}, function timeout() { // step to execute if check has failed
				    if(this.exists('a._sEo')) {
		    			casper.thenClick('a._sEo', function(){
							casper.waitFor(function check() {
				   				return this.evaluate(function() {
				        			return document.querySelector('div._ppj').querySelectorAll('div._kpj').length > 6;
				   				 });
							}, function then() {
								qtd.add();
					    		console.log('b:' + qtd.value);
			        			fs.write(file_path + qtd.value + '.html', name + '\n' + this.getHTML('div._ppj'), 'w');
			        		},function timeout() { console.log('c: fail') },
			        		4000);
		    			});
					} else {
						console.log('d: fail');
					}	
				},
				4000); 
		});
	});

	return qtd;
}

// Roda o casper
casper.run();
