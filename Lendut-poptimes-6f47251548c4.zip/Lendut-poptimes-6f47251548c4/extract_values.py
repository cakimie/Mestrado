#!/usr/bin/python

"""Extract_values.py: read HTML and extract popular times values from cities defined on main"""
"""Usage: ./extract_values.py """

import sys, os, errno, json, cssutils
from bs4 import BeautifulSoup

def get_values_from_category(path):
  venues = sorted(os.listdir(path))
  venues_values = []

  for venue in venues:
    venues_values.append(get_values_from_venue(path, venue))

  # venues_values.append(get_values_from_venue(path, venues[0]))
  # venues_values.append(get_values_from_venue(path, venues[1]))

  return venues_values


def isfloat(value):
  try:
    float(value)
    return True
  except:
    return False


def get_values_from_venue(path, filename):
  values = [['0'] * 24 for _ in range(7)]

  with open(path + filename, "r") as file:
    soup = BeautifulSoup(file,'html.parser')
    days = soup.findAll("div",{"class":"_kpj"})
    
    for i in range(7):
      hours_parent = days[i].find("div", {"class": "_Toj"})

      if hours_parent is not None:
        hours = hours_parent.findChildren()
        j = 0
   
        for hour in hours:
          if hour.has_attr("style"):
            css = hour["style"]
            hour_value = cssutils.parseStyle(css).height
            if isfloat(hour_value[:-2]):
              values[i][(j+6)%24] = hour_value[:-2]
          j+=1

  return values


def format_venues_values(venues):
  data = ""
  
  for venue in venues:
    week = ""
    for day in venue:
      hours = ",".join(day)
      week += hours + "\n"
    data += week + "\n"

  return data


def make_sure_path_exists(path):
  try:
    os.makedirs(path)
  except OSError as exception:
    if exception.errno != errno.EEXIST:
      raise


def save_to_file(path, category, data):
  make_sure_path_exists(path)

  with open(path + category + ".txt", "w") as file:
    file.write("%s" % data)
  print("File %s created at %s.") % (category, path)


def main():
  categories = ["bakeries", "bars", "coffee", "dance clubs", "restaurants","shopping centers"]
  
  country = "br"
  cities = ["curitiba", "sao paulo", "rio de janeiro"]
  for city in cities:
    for category in categories:
      from_path = ("poptimes_raw/%s/%s/%s/") % (country, city, category)
      to_path = ("poptimes/%s/%s/") % (country, city)
      print("Extracting...")
      values = get_values_from_category(from_path)
      data = format_venues_values(values)
      save_to_file(to_path, category, data[:-1])

  country = "us"
  cities = ["chicago", "new york", "san francisco"]
  for city in cities:
    for category in categories:
      from_path = ("poptimes_raw/%s/%s/%s/") % (country, city, category)
      to_path = ("poptimes/%s/%s/") % (country, city)
      print("Extracting...")
      values = get_values_from_category(from_path)
      data = format_venues_values(values)
      save_to_file(to_path, category, data[:-1])

  #TESTE
  # city = "curitiba"
  # category = "shopping centers"
  # from_path = ("poptimes_raw/%s/%s/%s/") % (country, city, category)
  # to_path = ("poptimes/%s/%s/") % (country, city)
  # values = get_values_from_category(from_path)
  # data = format_venues_values(values)
  # save_to_file(to_path, category, data[:-1])

if __name__ == "__main__":
  main()