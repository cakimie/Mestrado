library("dtwclust")
library("TSclust")

#read all venues distributions for country,city
place <- "br/sao paulo"

categories <- list.files(path=paste("signatures/weekends_clust/",place,sep=""), pattern="*.txt", full.names=FALSE, recursive=FALSE)

for (j in 1:length(categories)){
  m <- read.table(paste("signatures/weekends_clust/",place,"/",categories[j],sep=""),sep=',');
  
  #normalize
  newM <- c()
  for (h in 1:nrow(m)){
    if(max(m[h,]) != 0){
      normalizado1 <- m[h,]/max(m[h,])
      newM <- rbind(newM,normalizado1)  
    }else{
      newM <- rbind(newM,m[h,])  
    }
  }
  
  transpose = t(newM)
  timeseries <- ts(transpose,start = 0,end = 23)
  
  # find centroid
  cent <- colMeans(newM)

  # iterated processing DBA 
  dtw_avg <- matrix(,nrow=50,ncol=24)
  for(i in 1:50){
    dtw_avg[i,] <- DBA(t(timeseries), trace = F)
  }
  
  #calculate DBA
  signature <- DBA(dtw_avg,centroid = cent,trace = TRUE)
  
  #para salvar em eps
  setEPS()
    postscript(paste("signatures/by_category/",place,"/weekends_",substr(categories[j],1,nchar(categories[j])-4),".eps",sep = ""))
    
    #color
    #'mar' define as marges da figura
    #'par' define as configuracoes atuais dos plots 
    par(cex.lab=2, cex.axis=1.5, mar= c(5, 5, 4, 2) + 0.1)
    seriesNum <- ncol(timeseries)
    ts.plot(timeseries,xlab="Hora",ylab="Popularidade",gpars=list(xaxt="n",col=rep(rainbow(10),seriesNum)),main="")
    par(new=TRUE)
    ts.plot(signature,xlab="Hora",ylab="Popularidade",gpars=list(xaxt="n",yaxt="n",lwd=5),main="")
    axis(1, at=1:24, labels = seq(from=0, to=23, by = 1), las=2)
  dev.off()
}    


